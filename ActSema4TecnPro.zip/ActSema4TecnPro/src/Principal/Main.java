/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Principal;
import Vista.FormVideojuego;
/**
 *
 * @author mrfab
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        FormVideojuego fm = new FormVideojuego();
        fm.setTitle("Registrar Videojuego");
        fm.setLocationRelativeTo(null);
        fm.setVisible(true);
    }
    
}
